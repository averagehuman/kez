.. :changelog:

History
-------

0.3.0 (2013-09-17)
++++++++++++++++++

* Allows for overrides of default repo_aliases and hosting services.


0.2.0 (2013-09-08)
++++++++++++++++++

* Improved test coverage to 100%.
* Added coveralls.
* Better analysis of repos.

0.1.0 (2013-09-08)
++++++++++++++++++

* First release on PyPI.