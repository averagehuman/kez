#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Daniel Greenfeld'
__email__ = 'pydanny@gmail.com'
__version__ = '0.3.0'

from .main import watdarepo
from .main import identify_vcs
from .main import identify_hosting_service
