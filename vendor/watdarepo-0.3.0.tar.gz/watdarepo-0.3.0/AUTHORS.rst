=======
Credits
=======

Development Lead
----------------

* Daniel Greenfeld <pydanny@gmail.com>

Contributors
------------

* Flavio Curella